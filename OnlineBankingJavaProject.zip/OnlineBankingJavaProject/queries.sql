create table Account_Master(Account_ID number(10) primary key,Account_Type varchar2(25),Account_Balance number(15),Open_Date date);

create table Customer(Account_ID number(10) references Account_Master(Account_ID),
customer_name varchar2(50),Email varchar2(30),Address varchar2(100),Pancard varchar2(15));

create table Transactions(Transaction_ID number,Tran_description varchar2(100),DateofTransaction date,TransactionType varchar2(1),TranAmount number(15),Account_No number(10),Account_ID number(10) references Account_Master(Account_ID));

CREATE TABLE Service_Tracker(Service_ID NUMBER, 
Service_Description VARCHAR2(100),
Account_ID NUMBER  references Account_Master(Account_ID),
 Service_Raised_Date DATE ,
Service_status VARCHAR2(20));

CREATE TABLE User_Table(Account_ID NUMBER  references Account_Master(Account_ID),user_id NUMBER,
login_password VARCHAR2(15),
secret_question VARCHAR2(50),
Transaction_password VARCHAR2(15),
lock_status VARCHAR2(1));

	CREATE TABLE Fund_Transfer(FundTransfer_ID NUMBER ,
Account_ID NUMBER(10)  references Account_Master(Account_ID),Payee_Account_Id NUMBER(10) ,
 Date_Of_Transfer DATE, Transfer_Amount NUMBER(15));

CREATE TABLE PayeeTable(Account_Id NUMBER  references Account_Master(Account_ID),Payee_Account_Id NUMBER references Fund_Transfer(Payee_Account_Id), Nick_name VARCHAR2(40));

create table Users_Admin(User_Name varchar2(20) primary key,Password Number);




insert into Users_Admin values('satya',311);


insert into Account_Master values(100201,'savings','20000','12-May-2018');
insert into Account_Master values(100202,'savings','54000','10-Jun-2018');
insert into Account_Master values(100203,'current','20500','22-Jan-2018');
insert into Account_Master values(100204,'savings','57000','02-Aug-2018');
insert into Account_Master values(100205,'savings','20000','12-May-2018');
insert into Account_Master values(100206,'current','20000','12-May-2018');
insert into Account_Master values(100207,'savings','56700','08-Feb-2018');



insert into User_Table values(100201,100000,'milky','pinky','swathi','g');

Weekly Data:
insert into transactions values(8,'Scholarship','27-Jul-2018','C',6000,100786,100201);
insert into transactions values(7,'BeautyParlour','27-Jul-2018','D',2000,100567,100201);
insert into transactions values(6,'Shopping','27-Jul-2018','D',3000,100576,100201);
insert into transactions values(5,'SchoolFee','27-Jul-2018','D',10000,100306,100201);


Monthly Data:
insert into transactions values(4,'GasBooking','25-Jun-2018','D',5000,100570,100203);
insert into transactions values(3,'Food','15-Jun-2018','D',10000,100580,100202);



Quarterly Data:
insert into transactions values(2,'Scholarship','11-Feb-2018','C',6000,100500,100203);



Yearly Data:
insert into transactions values(1,'Shopping','24-Jan-2018','D',10000,100700,100202);




delete from Account_Master where account_id=100256;

delete from Account_Master where account_id=100209;

delete from Account_Master where account_id=100234;

delete from Account_Master where account_id=100342;

delete from Account_Master where account_id=100678;



insert into Service_Tracker values(201,'Cheque Book Request',100201,'21-Jun-2018','processing');

insert into Service_Tracker values(202,'Cheque Book Request',100202,'11-Jul-2018','pending');

insert into Service_Tracker values(203,'Cheque Book Request',100203,'01-Aug-2018','done');


delete from Service_Tracker where account_id=100201;
