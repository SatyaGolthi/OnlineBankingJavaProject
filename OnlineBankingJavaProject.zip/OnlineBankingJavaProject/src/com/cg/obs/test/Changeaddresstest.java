package com.cg.obs.test;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.cg.obs.Dao.CustomerDao;
import com.cg.obs.Dao.CustomerDaoImpl;
import com.cg.obs.Dto.CustomerDetails;
import com.cg.obs.Dto.TransactionDetails;
import com.cg.obs.Exception.OnlineException;

public class Changeaddresstest {
	
	@Test
	public void test() {
		
				
		CustomerDao	dao = new CustomerDaoImpl();
		//creating bean and adding values.
		CustomerDetails cd=new CustomerDetails();
		cd.setAccountid(100204);
		cd.setCustomername("Pinky");
		cd.setAddress("Hyderabad");
		cd.setEmail("pinky@gmail.com");
		cd.setPancard("QWDST7894S");
		
		
		try {
			int id = dao.CreateAccount(cd);
			assertTrue(id!=0);
		} catch (OnlineException e) {
			e.printStackTrace();
		}
	
	}
		
	

}

	