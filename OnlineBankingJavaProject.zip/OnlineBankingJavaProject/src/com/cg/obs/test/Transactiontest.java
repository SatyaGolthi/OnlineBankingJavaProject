package com.cg.obs.test;

import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.junit.Test;

import com.cg.obs.Dao.TransactionDao;
import com.cg.obs.Dao.TransactionDaoImpl;
import com.cg.obs.Dto.TransactionDetails;
import com.cg.obs.Exception.OnlineException;

public class Transactiontest {

	
	@Test
	public void testgetTransactionDetails()
	{
		TransactionDao	dao = new TransactionDaoImpl();
		
		try {
			
			List<TransactionDetails> td = dao.getTransactionDetails("05-07-2018", "11-07-2018" );
			assertNotNull(td);
		} catch (OnlineException e) {
			e.printStackTrace();
		}
	
	}


}
