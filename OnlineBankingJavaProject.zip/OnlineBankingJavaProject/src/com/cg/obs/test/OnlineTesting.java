package com.cg.obs.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.cg.obs.Dao.UserTableDao;
import com.cg.obs.Dao.UserTableDaoImpl;
import com.cg.obs.Dto.UserTableDetails;
import com.cg.obs.Exception.OnlineException;



public class OnlineTesting {
	int Userid;
	String Loginpassword;

	@Test
	public void TestforAddPurchasedetails() throws  OnlineException
	{
	UserTableDao pd=new UserTableDaoImpl();
	int Actual;
	int res=0;
	UserTableDetails utb=new UserTableDetails ();
	utb.setUserid(100000);
	utb.setLoginpassword("milky");
	
	
	res=pd.getAccountId(Userid, Loginpassword);
	if(res==0)
	{
		Actual=0;
		
	}
	else{
		Actual=1;
	}
 assertEquals(0,Actual);
	
	}
}


