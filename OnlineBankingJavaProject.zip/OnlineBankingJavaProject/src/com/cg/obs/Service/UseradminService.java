package com.cg.obs.Service;

import com.cg.obs.Exception.OnlineException;

public interface UseradminService {

	
	public boolean validateCredentials1(String username,String password) throws OnlineException;
}
