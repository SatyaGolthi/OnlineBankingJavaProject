package com.cg.obs.Service;

import com.cg.obs.Dao.PayeeTableDao;

public class PayeeTableServiceImpl implements PayeeTableService, PayeeTableDao {

}
