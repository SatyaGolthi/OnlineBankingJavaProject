package com.cg.obs.Service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.obs.Dao.CustomerDao;
import com.cg.obs.Dao.CustomerDaoImpl;
import com.cg.obs.Dto.CustomerDetails;
import com.cg.obs.Exception.OnlineException;

public class CustomerServiceImpl implements CustomerService {
CustomerDao dao;
public CustomerServiceImpl() {
	dao=new CustomerDaoImpl();
}


@Override
public int CreateAccount(CustomerDetails customer) throws OnlineException {
	
	return dao.CreateAccount(customer);
}
@Override
public boolean isValidCustomer(CustomerDetails customer) {
	
	Pattern pattern=Pattern.compile("[A-Z][a-z]{2,20}");
	Matcher matcher=pattern.matcher(customer.getCustomername());
	
	{
		if(matcher.matches())
		{
			if(Pattern.matches("[A-Z]{5}\\d{4}[A-Z]{1}",customer.getPancard())){
				
				if(Pattern.matches("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
						+ "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$",customer.getEmail())){
					return true;
				}
				return true;
			}
			else return false;
		}
		
	}
	return false;
	}


	@Override
	public int updatedetails(CustomerDetails customer) throws OnlineException {
		// TODO Auto-generated method stub
		return dao.updatedetails(customer);
	}

}
