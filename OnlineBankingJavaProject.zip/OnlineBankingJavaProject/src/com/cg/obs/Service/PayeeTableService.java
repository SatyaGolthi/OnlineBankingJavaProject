package com.cg.obs.Service;

public interface PayeeTableService {

}
