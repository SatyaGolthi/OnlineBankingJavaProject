package com.cg.obs.Service;

import com.cg.obs.Dto.FundTransferDetails;
import com.cg.obs.Exception.OnlineException;

public interface FundTransferService {
	public int addDetails(FundTransferDetails fund) throws OnlineException;
}
