package com.cg.obs.Service;

import com.cg.obs.Dao.UseradminDao;
import com.cg.obs.Dao.UseradminDaoImpl;
import com.cg.obs.Exception.OnlineException;

public class UseradminServiceImpl implements UseradminService {

	
	UseradminDao dao;
	public  UseradminServiceImpl() {
			dao=new UseradminDaoImpl();
}
	public boolean validateCredentials1(String username, String password)
			throws OnlineException {
		
		return dao.validateCredentials1(username, password);
	}
	
}
