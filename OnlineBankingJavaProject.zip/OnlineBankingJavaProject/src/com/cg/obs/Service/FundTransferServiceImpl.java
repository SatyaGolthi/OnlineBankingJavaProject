package com.cg.obs.Service;

import com.cg.obs.Dao.FundTransferDao;
import com.cg.obs.Dao.FundTransferDaoImpl;
import com.cg.obs.Dto.FundTransferDetails;
import com.cg.obs.Exception.OnlineException;

public class FundTransferServiceImpl implements FundTransferService,
		FundTransferDao {
	FundTransferDao dao;
	public FundTransferServiceImpl()
	{
		dao=new FundTransferDaoImpl();
	}
	
	@Override
	public int addDetails(FundTransferDetails fund) throws OnlineException {
		
		return dao.addDetails(fund);
	}
	
}
