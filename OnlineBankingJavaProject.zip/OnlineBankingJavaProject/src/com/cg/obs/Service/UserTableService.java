package com.cg.obs.Service;

import com.cg.obs.Dto.UserTableDetails;
import com.cg.obs.Exception.OnlineException;

public interface UserTableService {
	public boolean validateCredentials(int username,String password) throws OnlineException;
	public int getAccountId(int username,String password) throws OnlineException;
	public int updatedetails(UserTableDetails user) throws OnlineException;
}
