package com.cg.obs.Service;

import java.util.List;

import com.cg.obs.Dao.TransactionDao;
import com.cg.obs.Dao.TransactionDaoImpl;
import com.cg.obs.Dto.TransactionDetails;
import com.cg.obs.Exception.OnlineException;

public class TransactionServiceImpl implements TransactionService {
	TransactionDao dao;
	public TransactionServiceImpl() {
		dao=new TransactionDaoImpl();
}
	
	
	@Override
	public List<TransactionDetails> getTransactionDetails(String date1,String date2)
			throws OnlineException {
		return dao.getTransactionDetails(date1,date2);
	}


	@Override
	public List<TransactionDetails> getTransactionDetails(int Accountid)
			throws OnlineException {
		
		return dao.getTransactionDetails1(Accountid);
	}


}
