package com.cg.obs.Service;

import java.util.List;

import com.cg.obs.Dto.TransactionDetails;
import com.cg.obs.Exception.OnlineException;

public interface TransactionService {
	
	public List<TransactionDetails> getTransactionDetails(String date1,String date2) throws OnlineException;
	public List<TransactionDetails> getTransactionDetails(int Accountid) throws OnlineException;
	
}
