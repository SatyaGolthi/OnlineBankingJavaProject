package com.cg.obs.Service;

import java.sql.Connection;
import java.util.List;

import com.cg.obs.Dao.ServiceTrackerDao;
import com.cg.obs.Dao.ServiceTrackerDaoImpl;
import com.cg.obs.Dto.ServiceTrackerDetails;
import com.cg.obs.Exception.OnlineException;
import com.cg.obs.Util.DatabaseConnection;

public class ServiceTrackerServiceImpl implements ServiceTrackerService{
		ServiceTrackerDao dao; 

	public ServiceTrackerServiceImpl() {
		dao = new ServiceTrackerDaoImpl();
	}



	@Override
	public List<ServiceTrackerDetails> getServiceTrackerDeatils(String Service_description) {
		
		return dao.getServiceTrackerDeatils(Service_description);
	}


	@Override
	public List<ServiceTrackerDetails> getServiceTrackerDeatils1(String Service_description) {

		return dao.getServiceTrackerDeatils1(Service_description);
	}



	@Override
	public int addServiceTracker(ServiceTrackerDetails tracker) throws OnlineException {
		
		return dao.addServiceTracker(tracker);
	}

}
