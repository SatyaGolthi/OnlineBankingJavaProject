package com.cg.obs.Service;

import com.cg.obs.Dao.UserTableDao;
import com.cg.obs.Dao.UserTableDaoImpl;
import com.cg.obs.Dto.UserTableDetails;
import com.cg.obs.Exception.OnlineException;

public class UserTableServiceImpl implements UserTableService, UserTableDao {
		UserTableDao dao;
		public UserTableServiceImpl() {
		dao=new UserTableDaoImpl();
		}


	/*@Override
	public int getAccountId(UserTableDetails account) throws OnlineException {
		// TODO Auto-generated method stub
		return dao.getAccountId(account);
	}*/
	@Override
	public boolean validateCredentials(int Userid, String Loginpassword)
			throws OnlineException {
		return dao.validateCredentials(Userid, Loginpassword);
	}
	@Override
	public int getAccountId(int Userid, String Loginpassword)
			throws OnlineException {
		// TODO Auto-generated method stub
		return dao.getAccountId(Userid, Loginpassword);
	}


	@Override
	public int updatedetails(UserTableDetails user) throws OnlineException {
		// TODO Auto-generated method stub
		return dao.updatedetails(user);
	}

}
