package com.cg.obs.Service;

import com.cg.obs.Dao.AccountMasterDao;
import com.cg.obs.Dao.AccountMasterDaoImpl;
import com.cg.obs.Dto.FundTransferDetails;
import com.cg.obs.Exception.OnlineException;

public class AccountMasterServiceImpl implements AccountMasterService,
		AccountMasterDao {

	AccountMasterDao dao;
	public AccountMasterServiceImpl()
	{
		dao=new AccountMasterDaoImpl();
	}
	@Override
	public int updatedetails(FundTransferDetails fund) throws OnlineException {

		return dao.updatedetails(fund);
	}
	

}
