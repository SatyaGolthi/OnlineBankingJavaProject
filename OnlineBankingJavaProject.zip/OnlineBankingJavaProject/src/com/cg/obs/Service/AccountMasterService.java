package com.cg.obs.Service;

import com.cg.obs.Dto.FundTransferDetails;
import com.cg.obs.Exception.OnlineException;

public interface AccountMasterService {
	public int updatedetails(FundTransferDetails fund) throws OnlineException;
}
