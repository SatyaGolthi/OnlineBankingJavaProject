package com.cg.obs.Service;

import com.cg.obs.Dto.CustomerDetails;
import com.cg.obs.Exception.OnlineException;

public interface CustomerService {
	
	public int CreateAccount(CustomerDetails customer) throws OnlineException;
	public boolean isValidCustomer(CustomerDetails customer);

	public int updatedetails(CustomerDetails customer) throws OnlineException;
}
