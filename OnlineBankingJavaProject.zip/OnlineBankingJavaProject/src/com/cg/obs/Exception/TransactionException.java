package com.cg.obs.Exception;

public class TransactionException {

	public TransactionException(String String) {
		
	}
}
