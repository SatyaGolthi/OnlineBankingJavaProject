package com.cg.obs.Exception;

public class AccountMasterException {

	public AccountMasterException(String string) {
	
	}
}
