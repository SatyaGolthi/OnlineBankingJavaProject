package com.cg.obs.Exception;

public class UserTableException {

	public UserTableException(String String) {
		
		
	}
}
