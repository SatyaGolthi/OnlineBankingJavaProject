package com.cg.obs.Exception;

public class ServiceTrackerException {

	public ServiceTrackerException(String String){
		
	}
}
