package com.cg.obs.Exception;

public class FundTransferException {

	public FundTransferException(String String) {
		
	}
}
