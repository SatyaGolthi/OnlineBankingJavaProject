package com.cg.obs.Exception;

public class PayeeTableException {

	public PayeeTableException(String string) {
		
	}
}
