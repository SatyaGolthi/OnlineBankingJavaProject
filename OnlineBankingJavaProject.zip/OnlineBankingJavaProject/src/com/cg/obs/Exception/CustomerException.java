package com.cg.obs.Exception;

public class CustomerException {
	public CustomerException(String String) {
		
	}

}
