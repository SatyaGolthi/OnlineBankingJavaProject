package com.cg.obs.Dto;

public class UserTableDetails {

	private Integer Accountid;
	private Integer Userid;
	public Integer getUserid() {
		return Userid;
	}
	public void setUserid(Integer userid) {
		Userid = userid;
	}
	private String Loginpassword;
	private String Secretquestion;
	private String Transactionpassword;
	private String Lockstatus;
	public Integer getAccountid() {
		return Accountid;
	}
	public void setAccountid(Integer accountid) {
		Accountid = accountid;
	}
	
	
	public String getLoginpassword() {
		return Loginpassword;
	}
	public void setLoginpassword(String loginpassword) {
		Loginpassword = loginpassword;
	}
	public String getSecretquestion() {
		return Secretquestion;
	}
	public void setSecretquestion(String secretquestion) {
		Secretquestion = secretquestion;
	}
	public String getTransactionpassword() {
		return Transactionpassword;
	}
	public void setTransactionpassword(String transactionpassword) {
		Transactionpassword = transactionpassword;
	}
	public String getLockstatus() {
		return Lockstatus;
	}
	public void setLockstatus(String lockstatus) {
		Lockstatus = lockstatus;
	}
	public void setUserid(int userid2) {
		// TODO Auto-generated method stub
		
	}
	 
}
