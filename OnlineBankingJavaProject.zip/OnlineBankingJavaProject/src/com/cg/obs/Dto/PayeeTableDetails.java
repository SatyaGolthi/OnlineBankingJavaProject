package com.cg.obs.Dto;

public class PayeeTableDetails {

	private Integer Accountid;
	private Integer Payeeaccountid;
	private String Nickname;
	public Integer getAccountid() {
		return Accountid;
	}
	public void setAccountid(Integer accountid) {
		Accountid = accountid;
	}
	public Integer getPayeeaccountid() {
		return Payeeaccountid;
	}
	public void setPayeeaccountid(Integer payeeaccountid) {
		Payeeaccountid = payeeaccountid;
	}
	public String getNickname() {
		return Nickname;
	}
	public void setNickname(String nickname) {
		Nickname = nickname;
	}
	
	
}
