package com.cg.obs.Dto;

public class CustomerDetails {

	private Integer Accountid;
	private String Customername;
	private String Email;
	private String Address;
	private String Pancard;
	public Integer getAccountid() {
		return Accountid;
	}
	public void setAccountid(Integer accountid) {
		Accountid = accountid;
	}
	public String getCustomername() {
		return Customername;
	}
	public void setCustomername(String customername) {
		Customername = customername;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getPancard() {
		return Pancard;
	}
	public void setPancard(String pancard) {
		Pancard = pancard;
	}
	
	
}

