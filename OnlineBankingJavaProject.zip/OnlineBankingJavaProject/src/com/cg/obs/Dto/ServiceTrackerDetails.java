package com.cg.obs.Dto;

import java.util.Date;

public class ServiceTrackerDetails {

	private Integer Serviceid;
	private String Servicedescription;
	private Integer Accountid;
	private Date Serviceraiseddate;
	private String Servicestatus;
	public Integer getServiceid() {
		return Serviceid;
	}
	public void setServiceid(Integer serviceid) {
		Serviceid = serviceid;
	}
	public String getServicedescription() {
		return Servicedescription;
	}
	public void setServicedescription(String servicedescription) {
		Servicedescription = servicedescription;
	}
	public Integer getAccountid() {
		return Accountid;
	}
	public void setAccountid(Integer accountid) {
		Accountid = accountid;
	}
	public Date getServiceraiseddate() {
		return Serviceraiseddate;
	}
	public void setServiceraiseddate(Date serviceraiseddate) {
		Serviceraiseddate = serviceraiseddate;
	}
	public String getServicestatus() {
		return Servicestatus;
	}
	public void setServicestatus(String servicestatus) {
		Servicestatus = servicestatus;
	}
	
	
}
