package com.cg.obs.Dto;

import java.util.Date;

public class TransactionDetails {

	private Integer Transactionid;
	private String Transactiondescription;
	private Date DateofTransaction;
	private String Transactiontype;
	private Double Transactionamount;
	private Integer Accountno;
	public Integer getTransactionid() {
		return Transactionid;
	}
	public void setTransactionid(Integer transactionid) {
		Transactionid = transactionid;
	}
	public String getTransactiondescription() {
		return Transactiondescription;
	}
	public void setTransactiondescription(String transactiondescription) {
		Transactiondescription = transactiondescription;
	}
	public Date getDateofTransaction() {
		return DateofTransaction;
	}
	public void setDateofTransaction(Date dateofTransaction) {
		DateofTransaction = dateofTransaction;
	}
	public String getTransactiontype() {
		return Transactiontype;
	}
	public void setTransactiontype(String transactiontype) {
		Transactiontype = transactiontype;
	}
	public Double getTransactionamount() {
		return Transactionamount;
	}
	public void setTransactionamount(Double transactionamount) {
		Transactionamount = transactionamount;
	}
	public Integer getAccountno() {
		return Accountno;
	}
	public void setAccountno(Integer accountno) {
		Accountno = accountno;
	}
	
	
}
