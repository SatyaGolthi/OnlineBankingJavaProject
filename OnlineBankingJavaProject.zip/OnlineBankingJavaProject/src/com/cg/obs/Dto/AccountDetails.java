package com.cg.obs.Dto;

import java.util.Date;

public class AccountDetails {

	private Integer Accountid;
	private String Accounttype;
	private Integer Accountbalance;
	private Date OpenDate;
	
	public Integer getAccountid() {
		return Accountid;
	}
	public void setAccountid(Integer accountid) {
		Accountid = accountid;
	}
	public String getAccounttype() {
		return Accounttype;
	}
	public void setAccounttype(String accounttype) {
		Accounttype = accounttype;
	}
	public Integer getAccountbalance() {
		return Accountbalance;
	}
	public void setAccountbalance(Integer accountbalance) {
		Accountbalance = accountbalance;
	}
	public Date getOpenDate() {
		return OpenDate;
	}
	public void setOpenDate(Date openDate) {
		OpenDate = openDate;
	}
	
	
	
}
