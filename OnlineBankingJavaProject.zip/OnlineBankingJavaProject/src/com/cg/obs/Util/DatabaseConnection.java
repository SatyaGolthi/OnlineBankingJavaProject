package com.cg.obs.Util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.obs.Exception.OnlineException;


public class DatabaseConnection {
	public static Connection getConnection(){
		
		String url="";
		String username="";
			String pwd="";
			String driver="";
			Connection con=null;
			
				try {
					InputStream in=
							new FileInputStream("jdbc.properties");
					Properties pr=new Properties();
					pr.load(in);
					url=pr.getProperty("url");
					pwd=pr.getProperty("pwd");
					driver=pr.getProperty("driver");
					username=pr.getProperty("username");
					Class.forName(driver);
	con=DriverManager.getConnection(url,username,pwd);
	System.out.println("Database connected..");
				} catch (ClassNotFoundException e) {
					System.out.println("Class no loaded");
				} catch (SQLException e) {
					e.printStackTrace();
					System.out.println("Not connected with DB..");
					
				} catch (IOException e){
					e.printStackTrace();
					
				}
	return con;
	}
	public static void main(String[] args)
	{
	getConnection();
		}
}
