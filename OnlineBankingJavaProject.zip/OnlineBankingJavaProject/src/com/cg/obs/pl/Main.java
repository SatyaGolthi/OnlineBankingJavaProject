package com.cg.obs.pl;



import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;


import com.cg.obs.Dto.AccountDetails;
import com.cg.obs.Dto.CustomerDetails;
import com.cg.obs.Dto.FundTransferDetails;
import com.cg.obs.Dto.ServiceTrackerDetails;
import com.cg.obs.Dto.TransactionDetails;
import com.cg.obs.Dto.UserTableDetails;
import com.cg.obs.Exception.OnlineException;
import com.cg.obs.Service.AccountMasterService;
import com.cg.obs.Service.AccountMasterServiceImpl;
import com.cg.obs.Service.CustomerService;
import com.cg.obs.Service.CustomerServiceImpl;
import com.cg.obs.Service.FundTransferService;
import com.cg.obs.Service.FundTransferServiceImpl;
import com.cg.obs.Service.ServiceTrackerService;
import com.cg.obs.Service.ServiceTrackerServiceImpl;
import com.cg.obs.Service.TransactionService;
import com.cg.obs.Service.TransactionServiceImpl;
import com.cg.obs.Service.UserTableServiceImpl;
import com.cg.obs.Service.UseradminServiceImpl;

public class Main {
	static Logger lg=Logger.getLogger(Main.class);
public static void main(String[] args) throws OnlineException {
	PropertyConfigurator.configure("log4j.properties");
	final int accId;
	 AccountMasterService accser=new AccountMasterServiceImpl();
		FundTransferService funser=new FundTransferServiceImpl();
	
	ServiceTrackerService sertrack = new ServiceTrackerServiceImpl();
	UserTableServiceImpl utsi=new UserTableServiceImpl();
	CustomerServiceImpl cust=new CustomerServiceImpl();
	int Accountid;
	Double Transferamount;
	int Service_Id;
	String Service_description;
	
	
	Scanner sc=new Scanner(System.in);
	
		while(true) {
		System.out.println("/****************/ Online Banking System /****************/");
		System.out.println("\n 1.Account Holders");
		System.out.println("\n 2.Bank Admin");
		System.out.println("\n 0.exit");
		System.out.println("***********************************************");
		System.out.println("Choose an operation");
		int obs= sc.nextInt();
		switch(obs)
		{
		
		case 1://Account Holders
			
			//System.out.println(" 1.Login into the system using his/her credentials. ");
			 System.out.println("      Login Page     ");
			 System.out.println("---------------------------------");
			
			int Userid;
			String Loginpassword;
			
				System.out.println("Enter UserId");
				  Userid=sc.nextInt();
				System.out.println("Enter LoginPassword");
				Loginpassword=sc.next();
				
				UserTableServiceImpl uts=new UserTableServiceImpl();  //UsersService object
							System.out.println(Userid+Loginpassword);
							UserTableDetails utd=new UserTableDetails();
							utd.setUserid(Userid);
							utd.setLoginpassword(Loginpassword);
							
				boolean Validation=uts.validateCredentials(Userid, Loginpassword);
				
				if(!Validation) 
				{
					System.out.println("UserId or Password is Incorrect!!");
				}
				
				
				else {
					System.out.println("Login Successful\n");
					int accId1=uts.getAccountId(Userid, Loginpassword);
					System.out.println("Account id :"+accId1);
					lg.info("login successfull");
					
			handleAccountHolder(cust,utsi,sertrack, accser,funser);
				}
			
			break;
		case 2://Admin
			

			CustomerService cs = new CustomerServiceImpl();
			
			 System.out.println("      Login Page     ");
			 System.out.println("---------------------------------");
			String username;
			String password;

			 System.out.println("Enter username :");
			username=sc.next();
			  System.out.println("Enter Password :");
			password=sc.next();

			UseradminServiceImpl uts1=new UseradminServiceImpl();  //UsersService object
						
			boolean Validation1=uts1.validateCredentials1(username, password);

			if(!Validation1) 
			{
				System.out.println("UserName or Password is Incorrect!!");
			}


			else {
				System.out.println("Login Successful\n");
			
			
			

			while (true) {
				
				
				System.out.println("*****Online Banking System*****");
				
				System.out.println("1. Create Account");
				System.out.println("\n2. View All Transaction Details");
				System.out.println("\n0. Exit");
				System.out.println("*********************************************************");
				System.out.println("\nChoose an Operation : ");

			int admin= sc.nextInt();
			switch(admin){

			case 1:
				
				 String Customername;
				 String Email;
				 String Address;
				 String Pancard;
				
				System.out.println("Enter Customer Name :");
				Customername=sc.next();
				System.out.println("Enter Email :");
				Email=sc.next();
				System.out.println("Enter Address :");
				Address=sc.next();
				System.out.println("Enter Pancard Number :");
				Pancard=sc.next();
				System.out.println("Enter Account Id :");
				Accountid=sc.nextInt();
				CustomerDetails user=new CustomerDetails();
				user.setAccountid(Accountid);
				user.setCustomername(Customername);
				user.setEmail(Email);
				user.setAddress(Address);
				user.setPancard(Pancard);
				boolean res=cs.isValidCustomer(user);
				System.out.println(res);
				
				if(res){
					
					int id=cs.CreateAccount(user);
					
					System.out.println("Account id :"+ id);
					
					}
					else
					{
						System.out.println("Invalid details entered.....");
					}
					break;
					
			case 2:
				
				TransactionService ts=new TransactionServiceImpl();
				

				List<TransactionDetails> list=ts.getTransactionDetails("21-01-2018","21-09-2018");
				
				if(list.size()==0)
				{
					System.out.println("Record not found");
				}
				else
				{
					for(TransactionDetails td : list)
					{
						System.out.println(td.getTransactionid()+" "+td.getTransactionamount()+" "+td.getTransactiondescription()+" "+td.getTransactiontype()+" "+td.getAccountno()+" "+td.getDateofTransaction());
						
					}
					
				}
				System.out.println("Successfully data retrived");
				lg.info("data retrived successfully");
				break;
			case 0:
				
				System.out.println("Thank You");
				break;
			}
			}
				
			}

}
		}
}

	private static void handleAccountHolder(CustomerServiceImpl cust,UserTableServiceImpl utsi,ServiceTrackerService sertrack, AccountMasterService accser,FundTransferService funser) throws OnlineException
	{
		Scanner sc=new Scanner(System.in);
		
		while(true) {
			
			//System.out.println(" 1.Login into the system using his/her credentials. ");
			System.out.println(" 1.View  Mini /Detailed statement of  all the accounts (Mulitple accounts , if any can be viewed) ");
			System.out.println(" 2.Request for change in communication address/mobile number for bank account ");
			System.out.println(" 3.Request for cheque book ");
			System.out.println(" 4.Track  service request ");
			System.out.println(" 5.Fund Transfer ");
			System.out.println(" 6.Change password ");
			System.out.println(" 7.Insert into Service Tracker");
			System.out.println("***********************************************");
			System.out.println(" Choose an Operation :");
	
			
			int choice=sc.nextInt();
			
			switch(choice)
			{
		/*	case 1:
				

				int Userid;
				String Loginpassword;
				
					System.out.println("Enter UserId");
					  Userid=sc.nextInt();
					System.out.println("Enter LoginPassword");
					Loginpassword=sc.next();
					
					UserTableServiceImpl uts=new UserTableServiceImpl();  //UsersService object
								System.out.println(Userid+Loginpassword);
								UserTableDetails utd=new UserTableDetails();
								utd.setUserid(Userid);
								utd.setLoginpassword(Loginpassword);
								
					boolean Validation=uts.validateCredentials(Userid, Loginpassword);
					
					if(!Validation) 
					{
						System.out.println("UserId or Password is Incorrect!!");
					}
					
					
					else {
						System.out.println("Login Successful\n");
						int accId=uts.getAccountId(Userid, Loginpassword);
						System.out.println("Account id :"+accId);
						lg.info("login successfull");
					}
				
			break;		
			*/
			case 1:
				System.out.println("Enter Accountid ");
				int Accountid= sc.nextInt();
				TransactionService ts=new TransactionServiceImpl();
				

				List<TransactionDetails> list=ts.getTransactionDetails(Accountid);
				
				if(list.size()==0)
				{
					System.out.println("Record not found");
				}
				else
				{
					for(TransactionDetails td : list)
					{
						System.out.println(td.getTransactionid()+" "+td.getTransactionamount()+" "+td.getDateofTransaction());
						
					}
				}
				break;

				
			case 2:
				
				System.out.println("Enter Accountid:");
				Accountid=sc.nextInt();
				
				System.out.println("Enter Address:");
			String Address=sc.next();
			CustomerDetails c=new CustomerDetails();
				
				c.setAccountid(Accountid);
				c.setAddress(Address);
				
				
			Accountid=cust.updatedetails(c);
			if(Accountid==0)
			{
				System.out.println("There is no data updated");
				
			}
			else
			{
			System.out.println("details updated successfully:"+Accountid);
			lg.info("details updated successfully:"+Accountid);
			}
			break;	
			
			case 3:
				System.out.println("Enter Service Description ");
				String Service_description= sc.next();
				List<ServiceTrackerDetails> list1= sertrack.getServiceTrackerDeatils(Service_description);
				if(list1.size()==0)
					System.out.println("No  Record found for you ...");
				else
				{
					for(ServiceTrackerDetails sertr : list1)
					{
						System.out.println("Service id:"+sertr.getServiceid());
					}
				}
				
				break;
				
			case 4:
				System.out.println("Enter Service Description ");
				Service_description= sc.next();
				List<ServiceTrackerDetails> list11= sertrack.getServiceTrackerDeatils(Service_description);
				if(list11.size()==0)
					System.out.println("No  Record found for you ...");
				else
				{
					for(ServiceTrackerDetails sertr : list11)
					{
						System.out.println("service status:"+sertr.getServicestatus());
					}
				}
				break;
				
				
			
				
			case 5:
				
				System.out.println("Enter Payee Accountid: ");
				 Accountid=sc.nextInt();
				 
				System.out.println("Enter Amount: ");
				double tranAmount=sc.nextDouble();
				
				System.out.println("Enter Account number to transfer money");
				int AccountId2=sc.nextInt();
				
				AccountDetails acc=new AccountDetails();
				
					FundTransferDetails fund=new FundTransferDetails();
					/*String d1=sc.nextLine();*/
				
					fund.setAccountid(Accountid);
					fund.setPayeeaccountid(AccountId2);
					
					fund.setTransferamount(tranAmount);
					 
					 try{
						 int id=funser.addDetails(fund);
						 fund.setFundtransferid(id);
						 System.out.println("\nTransfer inititated with id : "+id);
						 
					 } catch(OnlineException e)
					 {
						 System.out.println("Not Successfully completed");
						 System.out.println(e.getMessage());
					 }
				 
				acc.setAccountid(Accountid);
				acc.setAccountbalance((int)tranAmount);
				
				
			Accountid=accser.updatedetails(fund);
			
			
			System.out.println("details updated successfully:"+Accountid);
		
	
	
			break;

			
			case 6:
				
				String Loginpassword;
						
				System.out.println("Enter Accountid:");
				Accountid=sc.nextInt();
				
				System.out.println("Enter LoginPassword:");
				Loginpassword=sc.next();
			UserTableDetails u=new UserTableDetails();
				
				u.setAccountid(Accountid);
				u.setLoginpassword(Loginpassword);
			
				
			Accountid=utsi.updatedetails(u);
			System.out.println("details updated successfully:"+Accountid);
			break;
			
			
			case 7:
				 
				System.out.println("Enter Service Id :");
				int Service_Id=sc.nextInt();
				System.out.println("Enter Service Description :");
				Service_description=sc.next();
				System.out.println("Enter Account Id :");
				Accountid=sc.nextInt();
				System.out.println("Enter Service Status :");
				String Service_Status=sc.next();
				
				ServiceTrackerDetails tracker=new ServiceTrackerDetails();
				
				
				tracker.setServiceid(Service_Id);
				tracker.setServicedescription(Service_description);
				tracker.setAccountid(Accountid);
				tracker.setServicestatus(Service_Status);
					int id=sertrack.addServiceTracker(tracker);
					System.out.println("Account id :"+ Accountid);
					
					break;
			}
			}
	}
}



