package com.cg.obs.Dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.obs.Dto.TransactionDetails;
import com.cg.obs.Exception.OnlineException;
import com.cg.obs.Util.DatabaseConnection;

public class TransactionDaoImpl implements TransactionDao {

	
	
	@Override
public List<TransactionDetails> getTransactionDetails1(int Accountid) throws OnlineException {
		
		List<TransactionDetails> list= new ArrayList<TransactionDetails>();
		
		String sql="select Transaction_id,DateofTransaction,TranAmount  from Transactions where Account_Id=?";
		Connection con= DatabaseConnection.getConnection();
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			ps.setInt(1,Accountid);
			ResultSet rs= ps.executeQuery();
			while(rs.next()){
				TransactionDetails td= new TransactionDetails();
				Integer Transactionid=rs.getInt("Transaction_ID");
			
				Date  DateofTransaction=rs.getDate("DateofTransaction");
				
				Double Transactionamount=rs.getDouble("TranAmount");
				
				
				td.setTransactionid(Transactionid);
			
				LocalDate date= LocalDate.now();
				Date sqlDate= Date.valueOf(date);
				td.setDateofTransaction(DateofTransaction);
				
				td.setTransactionamount(Transactionamount);
				
				
		     	list.add(td);
		}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new OnlineException(e.getMessage());
		}
		return list;
	}

	
public List<TransactionDetails> getTransactionDetails(String date1,String date2) throws OnlineException {
		
		List<TransactionDetails> list= new ArrayList<TransactionDetails>();
		
		String sql="select * from transactions where DateofTransaction between ? and ?";
		Connection con= DatabaseConnection.getConnection();
		try {
			PreparedStatement ps= con.prepareStatement(sql);
			ps.setDate(1, java.sql.Date.valueOf(LocalDate.parse(date1, DateTimeFormatter.ofPattern("dd-MM-yyyy"))));
			ps.setDate(2, java.sql.Date.valueOf(LocalDate.parse(date2, DateTimeFormatter.ofPattern("dd-MM-yyyy"))));
			ResultSet rs= ps.executeQuery();
			while(rs.next()){
				TransactionDetails td= new TransactionDetails();
				Integer Transactionid=rs.getInt("Transaction_ID");
				String Transactiondescription=rs.getString("Tran_description");
				Date  DateofTransaction=rs.getDate("DateofTransaction");
				String Transactiontype=rs.getString("TransactionType");
				Double Transactionamount=rs.getDouble("TranAmount");
				Integer Accountno=rs.getInt("Account_No");
				
				td.setTransactionid(Transactionid);
				td.setTransactiondescription(Transactiondescription);
				LocalDate date= LocalDate.now();
				Date sqlDate= Date.valueOf(date);
				td.setDateofTransaction(DateofTransaction);
				td.setTransactiontype(Transactiontype);
				td.setTransactiontype("Saving");
				td.setTransactionamount(Transactionamount);
				td.setAccountno(Accountno);
				
		     	list.add(td);
		}
		} catch (SQLException e) {
			e.printStackTrace();
			throw new OnlineException(e.getMessage());
		}
		return list;
	
	
}



}
