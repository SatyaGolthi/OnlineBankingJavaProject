package com.cg.obs.Dao;

import com.cg.obs.Dto.CustomerDetails;
import com.cg.obs.Dto.ServiceTrackerDetails;
import com.cg.obs.Exception.OnlineException;

public interface CustomerDao {
	


    public int CreateAccount(CustomerDetails customer) throws OnlineException;
	public int updatedetails(CustomerDetails customer) throws OnlineException;

}
