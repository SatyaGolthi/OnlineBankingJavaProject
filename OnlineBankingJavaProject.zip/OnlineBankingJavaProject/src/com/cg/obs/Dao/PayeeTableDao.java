package com.cg.obs.Dao;

public interface PayeeTableDao {

}
