package com.cg.obs.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.obs.Dto.AccountDetails;
import com.cg.obs.Dto.FundTransferDetails;
import com.cg.obs.Exception.OnlineException;
import com.cg.obs.Util.DatabaseConnection;

public class AccountMasterDaoImpl implements AccountMasterDao {
	@Override
	public int updatedetails(FundTransferDetails fund)throws OnlineException
	{
	
		Connection con= DatabaseConnection.getConnection();
		String sql="select transfer_amount from  fund_transfer where fundtransfer_id=?";
		try{
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, fund.getFundtransferid());
	
			int rows=0;
			ResultSet  rs=ps.executeQuery();
			
			if(rs.next())
			{
				double amount = rs.getDouble("transfer_amount");
				
				String sql1="update Account_Master set Account_Balance=Account_Balance-? "
						+"where Account_Id=?";
				
				PreparedStatement pst=con.prepareStatement(sql1);
				pst.setDouble(1, amount);
				pst.setInt(2,fund.getAccountid());
				
				rows=pst.executeUpdate();
				
				String sql2="update Account_Master set Account_Balance=Account_Balance+? "
						+"where Account_Id=?";
				
				PreparedStatement pst1=con.prepareStatement(sql2);
				pst1.setDouble(1, amount);
				pst1.setInt(2,fund.getPayeeaccountid());
				
				rows=pst1.executeUpdate();
			
			}

			
					
			System.out.println("row Updated:"+rows);
		}
		
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return fund.getAccountid(); 
	}
}
