package com.cg.obs.Dao;

import com.cg.obs.Dto.FundTransferDetails;
import com.cg.obs.Exception.OnlineException;

public interface FundTransferDao {

	public int addDetails(FundTransferDetails fund) throws OnlineException;
}
