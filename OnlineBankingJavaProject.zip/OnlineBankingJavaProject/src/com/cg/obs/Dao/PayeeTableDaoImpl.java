package com.cg.obs.Dao;

public class PayeeTableDaoImpl implements PayeeTableDao {

}
