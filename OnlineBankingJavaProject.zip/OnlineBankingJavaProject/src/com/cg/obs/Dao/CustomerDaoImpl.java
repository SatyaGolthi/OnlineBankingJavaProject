package com.cg.obs.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.cg.obs.Dto.CustomerDetails;
import com.cg.obs.Dto.ServiceTrackerDetails;
import com.cg.obs.Exception.OnlineException;
import com.cg.obs.Service.CustomerServiceImpl;
import com.cg.obs.Util.DatabaseConnection;

public class CustomerDaoImpl implements CustomerDao {
	
	
	

public int CreateAccount(CustomerDetails customer) throws OnlineException {
		
		int Accountid=0;
		Connection con=DatabaseConnection.getConnection();
		String sql="insert into "
                +"Customer(Account_ID,customer_name,Email,Address,Pancard)"
                +"values(?,?,?,?,?)";
		try{	
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, customer.getAccountid());
			ps.setString(2, customer.getCustomername());
			ps.setString(3, customer.getEmail());
			ps.setString(4, customer.getAddress());
			ps.setString(5,customer.getPancard());
			int rows=ps.executeUpdate();
			
			if(rows>0)
				return customer.getAccountid();
			
	
			} catch (SQLException e) {
				System.out.println (e.getMessage());
			}
			return 0;
		}

	
	
	
	
	
	@Override
	public int updatedetails(CustomerDetails customer)throws OnlineException
	{
		//int rows=0;
		Connection con= DatabaseConnection.getConnection();
		String sql="update Customer set Address=? "
				+"where Account_id=?";
		try{
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,customer.getAddress());
			ps.setInt(2,customer.getAccountid());
			int rows=ps.executeUpdate();
			System.out.println("row Updated:"+rows);
			return customer.getAccountid();
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	
		return 0; 
	}
}
