package com.cg.obs.Dao;

import java.util.List;

import com.cg.obs.Dto.TransactionDetails;
import com.cg.obs.Exception.OnlineException;

public interface TransactionDao {
	public List<TransactionDetails> getTransactionDetails1(int Accountid) throws OnlineException;
	public List<TransactionDetails> getTransactionDetails(String date1,String date2) throws OnlineException;

}
