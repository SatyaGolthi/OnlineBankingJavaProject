package com.cg.obs.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.obs.Dto.FundTransferDetails;
import com.cg.obs.Exception.OnlineException;
import com.cg.obs.Util.DatabaseConnection;

public class FundTransferDaoImpl implements FundTransferDao {
	
	@Override
	public int addDetails(FundTransferDetails fund) throws OnlineException {

Connection conn=DatabaseConnection.getConnection();
		
		int Fundtransferid=0;
		String sql=" insert into Fund_Transfer(FundTransfer_Id,Account_Id,Payee_Account_Id,Date_Of_Transfer,Transfer_Amount)"
				+ "	values(FundTransfer_Id_seq.nextval,?,?,?,?)";
        
		
		try
		{
			PreparedStatement ps=conn.prepareStatement(sql);
			
		
			

			ps.setInt(1, fund.getAccountid());
			ps.setInt(2, fund.getPayeeaccountid());
			
			/*Date sqldate= Date.valueOf(fund.getDateoftransfer());*/
			ps.setDate(3, new java.sql.Date(new java.util.Date().getTime()));
			ps.setDouble(4, fund.getTransferamount());
			int rows=ps.executeUpdate();
			
			String query= "select FundTransfer_Id_seq.currval from dual";
			Statement s= conn.createStatement();
			ResultSet rs= s.executeQuery(query);
			if(rs.next())
			{
				Fundtransferid= rs.getInt(1);
				
				return Fundtransferid;
			}
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
		return 0;
	
	}

}
