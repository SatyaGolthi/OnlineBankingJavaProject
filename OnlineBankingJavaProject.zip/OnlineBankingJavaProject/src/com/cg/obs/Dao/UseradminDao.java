package com.cg.obs.Dao;

import com.cg.obs.Exception.OnlineException;

public interface UseradminDao {
	
	public boolean validateCredentials1(String username,String password) throws OnlineException;

}
