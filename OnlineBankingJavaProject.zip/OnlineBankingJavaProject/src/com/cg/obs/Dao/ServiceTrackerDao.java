package com.cg.obs.Dao;

import java.util.List;

import com.cg.obs.Dto.ServiceTrackerDetails;
import com.cg.obs.Exception.OnlineException;

public interface ServiceTrackerDao {
	
	public int addServiceTracker(ServiceTrackerDetails tracker) throws OnlineException;
	public List<ServiceTrackerDetails> getServiceTrackerDeatils(String Service_description); 
	public List<ServiceTrackerDetails> getServiceTrackerDeatils1(String Service_description); 


}
