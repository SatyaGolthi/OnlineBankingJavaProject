package com.cg.obs.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.obs.Dto.UserTableDetails;
import com.cg.obs.Dto.Useradmindetails;
import com.cg.obs.Exception.OnlineException;
import com.cg.obs.Util.DatabaseConnection;

public class UseradminDaoImpl implements UseradminDao {
	
	private String New_password;

	public boolean validateCredentials1(String username,String password) throws OnlineException {
		String sql="select * from  Users_Admin where User_Name=? and Password=?";
		Useradmindetails dto = null;
		boolean Validation=false;
		try {
			Connection con=DatabaseConnection.getConnection();

			PreparedStatement s=con.prepareStatement(sql);
			s.setString(1, username);
			s.setString(2, password);
			
			ResultSet rs=s.executeQuery();
			
			while(rs.next()){
			Validation=true;
			}
			
		} catch (SQLException e) {
			Validation= false;
		}
		return Validation;
	}

}
