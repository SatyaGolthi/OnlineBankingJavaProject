package com.cg.obs.Dao;

import com.cg.obs.Dto.CustomerDetails;
import com.cg.obs.Dto.UserTableDetails;
import com.cg.obs.Exception.OnlineException;

public interface UserTableDao {
	public boolean validateCredentials(int username,String password) throws OnlineException;
	public int getAccountId(int Userid,String Loginpassword) throws OnlineException;
	public int updatedetails(UserTableDetails user) throws OnlineException;
}
