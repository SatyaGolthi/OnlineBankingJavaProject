package com.cg.obs.Dao;

import java.sql.Connection;



import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cg.obs.Dto.ServiceTrackerDetails;
import com.cg.obs.Exception.OnlineException;
import com.cg.obs.Util.DatabaseConnection;


public class ServiceTrackerDaoImpl implements ServiceTrackerDao {

	@Override
	public List<ServiceTrackerDetails> getServiceTrackerDeatils(String Service_description) {
		List<ServiceTrackerDetails> list1= new ArrayList<ServiceTrackerDetails>();
		Connection con= DatabaseConnection.getConnection();
		String sql="select Service_Id,Service_Status from Service_Tracker where Service_Description=?";

		
		try
		{
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, Service_description);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next())
			{
				ServiceTrackerDetails service=new ServiceTrackerDetails();
				service.setServiceid(rs.getInt("Service_Id"));		
				service.setServicestatus(rs.getString("Service_Status"));
				list1.add(service);
			}
		}
		catch (SQLException e) 
		{
			System.out.println(e.getMessage());
		}
		
		return list1;
	}




	@Override
	public List<ServiceTrackerDetails> getServiceTrackerDeatils1(String Service_description) {
		List<ServiceTrackerDetails> list= new ArrayList<ServiceTrackerDetails>();
		Connection con= DatabaseConnection.getConnection();
		String sql="select Service_Status from Service_Tracker where Service_Description=?";

		
		try
		{
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, Service_description);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next())
			{
				ServiceTrackerDetails service=new ServiceTrackerDetails();
				service.setServicestatus(rs.getString("Service_Status"));				
				list.add(service);
			}
		}
		catch (SQLException e) 
		{
			System.out.println(e.getMessage());
		}
		
		return list;
	}



	@Override
	public int addServiceTracker(ServiceTrackerDetails tracker) throws OnlineException {
		int Serviceid=0;
		Connection con=DatabaseConnection.getConnection();
		String sql="insert into "
                +"Service_Tracker(Service_Id,Service_description,Account_ID,Service_Status,Service_raised_date)"
                +"values(?,?,?,?,?)";
		try{	
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, tracker.getServiceid());
			ps.setString(2, tracker.getServicedescription());
			ps.setInt(3, tracker.getAccountid());
			ps.setString(4, tracker.getServicestatus());
			LocalDate date=LocalDate.now();
			Date sqlDate= Date.valueOf(date);
			ps.setDate(5, sqlDate);
			int rows=ps.executeUpdate();
			
			if(rows>0)
				return tracker.getServiceid();
			
	
			} catch (SQLException e) {
				System.out.println (e.getMessage());
			}
			return 0;

	}	
}

