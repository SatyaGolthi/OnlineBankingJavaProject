package com.cg.obs.Dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



import java.sql.Statement;
import java.time.LocalDate;



import com.cg.obs.Dto.AccountDetails;
import com.cg.obs.Dto.CustomerDetails;
import com.cg.obs.Dto.UserTableDetails;
import com.cg.obs.Exception.OnlineException;
import com.cg.obs.Util.DatabaseConnection;

public class UserTableDaoImpl implements UserTableDao {
	
	
	
	
	public boolean validateCredentials(int Userid,String Loginpassword) throws OnlineException {
		String sql="select * from  User_Table where user_id=? and login_password=?";
		UserTableDetails dto = null;
		boolean Validation=false;
		try {
			Connection con=DatabaseConnection.getConnection();

			PreparedStatement s=con.prepareStatement(sql);
			s.setInt(1, Userid);
			s.setString(2, Loginpassword);

			ResultSet rs=s.executeQuery();
			
			while(rs.next()){
			Validation=true;
			}
			
		} catch (SQLException e) {
			Validation= false;
		}
		return Validation;
	}


	
@Override
	public final int getAccountId(int Userid,String Loginpassword) throws OnlineException{
	
		String sql="select Account_Id"
				+ " from User_Table where user_id=? and login_password=? ";
				int AccountId=0;
		Connection con= DatabaseConnection.getConnection();
	
			try {
				PreparedStatement ps= con.prepareStatement(sql);
				UserTableDetails ub= new UserTableDetails();
				ps.setInt(1,Userid);
				ps.setString(2,Loginpassword);
				
				
				

				
					ResultSet rs= ps.executeQuery();
					if(rs.next()) 
						
						 AccountId= rs.getInt("Account_Id");
						
						
						
						
				
				} catch (SQLException e) {
					throw new OnlineException("No records found");
				}
				
			return AccountId;
	}



@Override
public int updatedetails(UserTableDetails user)throws OnlineException
{
	
	Connection con= DatabaseConnection.getConnection();
	String sql="update User_Table set login_password=? "
			+"where Account_id=?";
	try{
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1,user.getLoginpassword());
		ps.setInt(2,user.getAccountid());
		int rows=ps.executeUpdate();
		System.out.println("row Updated:"+rows);
		return user.getAccountid();
		
	}
	catch(SQLException e)
	{
		e.printStackTrace();
	}

	return 0; 
}




}





			
				
				
				
				
				
				
				
				
		
